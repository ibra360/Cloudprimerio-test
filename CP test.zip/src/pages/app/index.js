import AddPost from "./addpost";
import Home from "./home";

export { AddPost, Home };
